
require("trix")
require("@rails/actiontext")


// import 'trix/dist/trix.css'
// import './trix.scss'