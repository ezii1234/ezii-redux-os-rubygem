document.addEventListener("turbolinks:load", function(){



    $("#myModal");
});