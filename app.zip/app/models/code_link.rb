# typed: strict
class CodeLink < ApplicationRecord
  belongs_to :code_link_type
end
