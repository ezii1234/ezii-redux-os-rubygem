# typed: strong
class EziiZapping < ApplicationRecord
end
