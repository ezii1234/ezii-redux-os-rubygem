# typed: strong
class WitAiParseModel < ApplicationRecord
end
