# typed: strong
class Task < ApplicationRecord
end
