# typed: strict
class WhitelabelSystemExtension < ApplicationRecord
  belongs_to :comment
end
