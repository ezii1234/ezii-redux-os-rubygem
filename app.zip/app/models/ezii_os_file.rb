# typed: strong
class EziiOsFile < ApplicationRecord
end
