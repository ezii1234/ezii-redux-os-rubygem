# typed: strong
class Banal::Metadatum < ApplicationRecord
end
