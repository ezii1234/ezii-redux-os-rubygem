# typed: strong
class Banal::Employee < ApplicationRecord
end
