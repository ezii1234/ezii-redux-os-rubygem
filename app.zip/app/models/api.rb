# typed: strict
class Api < ApplicationRecord
  belongs_to :code
end
