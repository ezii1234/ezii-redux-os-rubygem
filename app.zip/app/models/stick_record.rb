# typed: strong
class StickRecord < ApplicationRecord
end
