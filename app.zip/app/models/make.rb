# typed: false
class Make < ApplicationRecord
    has_rich_text :description
end
