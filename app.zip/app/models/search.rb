# typed: strong
class Search < ApplicationRecord
end
