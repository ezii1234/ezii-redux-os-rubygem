# typed: strong
class KmzModel < ApplicationRecord
end
