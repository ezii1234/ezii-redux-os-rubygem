# typed: strong
class GltfModel < ApplicationRecord
end
