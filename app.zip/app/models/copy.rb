# typed: strong
class Copy < ApplicationRecord
end
