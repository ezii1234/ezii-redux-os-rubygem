# typed: strict
class UserTextCopy < ApplicationRecord
  belongs_to :ezii_adult_verify_and_signin
end
