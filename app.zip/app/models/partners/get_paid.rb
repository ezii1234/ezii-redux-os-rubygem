# typed: strong
class Partners::GetPaid < ApplicationRecord
end
