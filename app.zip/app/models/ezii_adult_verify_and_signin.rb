# typed: strong
class EziiAdultVerifyAndSignin < ApplicationRecord
end
