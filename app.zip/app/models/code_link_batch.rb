# typed: strict
class CodeLinkBatch < ApplicationRecord
  belongs_to :code_link
end
