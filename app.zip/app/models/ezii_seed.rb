# typed: strong
class EziiSeed < ApplicationRecord
end
