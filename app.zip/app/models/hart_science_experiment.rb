# typed: false
class HartScienceExperiment < ApplicationRecord
    has_rich_text :text
end
