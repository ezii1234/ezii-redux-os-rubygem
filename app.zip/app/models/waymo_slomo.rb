# typed: strong
class WaymoSlomo < ApplicationRecord
end
