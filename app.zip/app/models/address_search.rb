# typed: strong
class AddressSearch < ApplicationRecord
end
