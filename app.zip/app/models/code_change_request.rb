# typed: strong
class CodeChangeRequest < ApplicationRecord
end
