# typed: true
module Banal
  def self.table_name_prefix
    'banal_'
  end
end
