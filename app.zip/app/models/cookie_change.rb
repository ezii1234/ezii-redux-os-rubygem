# typed: strong
class CookieChange < ApplicationRecord
end
