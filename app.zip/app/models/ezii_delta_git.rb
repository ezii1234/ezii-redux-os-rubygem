# typed: strong
class EziiDeltaGit < ApplicationRecord
end
