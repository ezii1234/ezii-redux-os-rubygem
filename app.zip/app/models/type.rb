# typed: strict
class Type < ApplicationRecord
  belongs_to :code
end
