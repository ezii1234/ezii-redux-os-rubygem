# typed: strict
class AppDetectionStrategy < ApplicationRecord
  belongs_to :app_detection
end
