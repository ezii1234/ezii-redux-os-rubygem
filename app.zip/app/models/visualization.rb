# typed: strong
class Visualization < ApplicationRecord
end
