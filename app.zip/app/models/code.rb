# typed: strict
class Code < ApplicationRecord
  belongs_to :code_links
end
