# typed: strong
class Mercurial < ApplicationRecord
end
