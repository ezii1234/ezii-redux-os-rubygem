# typed: strong
class EziiGeminator < ApplicationRecord
end
