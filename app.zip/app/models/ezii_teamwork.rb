# typed: strong
class EziiTeamwork < ApplicationRecord
end
