# typed: strong
class Widget < ApplicationRecord
end
