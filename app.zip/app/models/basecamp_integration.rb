# typed: strong
class BasecampIntegration < ApplicationRecord
end
