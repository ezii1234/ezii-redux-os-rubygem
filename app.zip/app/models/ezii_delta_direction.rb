# typed: strict
class EziiDeltaDirection < ApplicationRecord
  belongs_to :ezii_delta_git
end
