# typed: strict
class CodeLinkType < ApplicationRecord
  belongs_to :type
end
