# typed: true
module Partners
  def self.table_name_prefix
    'partners_'
  end
end
