# typed: strong
class BanalBusinessTestcase < ApplicationRecord
end
