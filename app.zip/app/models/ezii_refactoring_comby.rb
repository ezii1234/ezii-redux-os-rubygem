# typed: strong
class EziiRefactoringComby < ApplicationRecord
end
