# typed: strong
class EziiRobotExperiment < ApplicationRecord
end
