# typed: strong
class BigDiscreteModule < ApplicationRecord
end
