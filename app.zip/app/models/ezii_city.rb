# typed: strict
class EziiCity < ApplicationRecord
  searchkick
end
