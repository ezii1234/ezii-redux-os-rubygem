# typed: strong
class Directory < ApplicationRecord
end
