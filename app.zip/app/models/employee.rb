# typed: strong
class Employee < ApplicationRecord
end
