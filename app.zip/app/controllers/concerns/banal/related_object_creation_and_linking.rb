# typed: strong
module Banal::RelatedObjectCreationAndLinking
#   extend ActiveSupport::Concern

#   included do
#     before_filter :create_and_link_related_object, only: [:create]
#   end

#   def create_and_link_related_object
#     p = params.permit(:object_id, :object_type)
#   end
end
