# typed: strong
module EziiGeminatorsHelper
end
