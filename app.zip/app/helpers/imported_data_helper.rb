# typed: strong
module ImportedDataHelper
end
