# typed: strong
module MercurialsHelper
end
