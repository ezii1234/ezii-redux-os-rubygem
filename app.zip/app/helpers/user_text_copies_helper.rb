# typed: strong
module UserTextCopiesHelper
end
