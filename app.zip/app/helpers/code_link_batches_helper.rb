# typed: strong
module CodeLinkBatchesHelper
end
