# typed: strong
module Partners::GetPaidsHelper
end
