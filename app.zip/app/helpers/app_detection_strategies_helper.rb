# typed: strong
module AppDetectionStrategiesHelper
end
