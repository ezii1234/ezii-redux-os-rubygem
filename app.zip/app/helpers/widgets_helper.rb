# typed: strong
module WidgetsHelper
end
