# typed: strong
module AddressSearchesHelper
end
