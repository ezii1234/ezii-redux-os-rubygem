# typed: strong
module EziiDeltaDirectionsHelper
end
