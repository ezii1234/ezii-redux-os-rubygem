# typed: strong
module EziiDeltaGitsHelper
end
