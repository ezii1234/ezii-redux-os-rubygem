# typed: strong
module BigDiscreteModulesHelper
end
