# typed: strong
module EziiCitiesHelper
end
