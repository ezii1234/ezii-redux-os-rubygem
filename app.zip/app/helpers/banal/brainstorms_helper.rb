# typed: strong
module Banal::BrainstormsHelper
end
