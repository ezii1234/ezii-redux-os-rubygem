# typed: strong
module Banal::MetadataHelper
end
