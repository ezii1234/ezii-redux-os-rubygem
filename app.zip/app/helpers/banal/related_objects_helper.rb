# typed: strong
module Banal::RelatedObjectsHelper
end
