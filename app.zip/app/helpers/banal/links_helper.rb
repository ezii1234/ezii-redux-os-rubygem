# typed: strong
module Banal::LinksHelper
end
