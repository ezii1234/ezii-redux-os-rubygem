# typed: strong
module Banal::DocumentsHelper
end
