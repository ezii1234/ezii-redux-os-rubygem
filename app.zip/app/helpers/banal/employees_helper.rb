# typed: strong
module Banal::EmployeesHelper
end
