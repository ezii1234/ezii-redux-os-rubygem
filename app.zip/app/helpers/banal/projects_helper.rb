# typed: strong
module Banal::ProjectsHelper
end
