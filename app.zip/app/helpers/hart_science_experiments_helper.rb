# typed: strong
module HartScienceExperimentsHelper
end
