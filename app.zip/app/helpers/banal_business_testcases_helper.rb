# typed: strong
module BanalBusinessTestcasesHelper
end
