# typed: strong
module CookieChangesHelper
end
