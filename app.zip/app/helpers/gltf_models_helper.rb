# typed: strong
module GltfModelsHelper
end
