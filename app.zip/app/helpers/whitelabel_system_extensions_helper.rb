# typed: strong
module WhitelabelSystemExtensionsHelper
end
