# typed: strong
module CodeLinksHelper
end
