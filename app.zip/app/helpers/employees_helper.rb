# typed: strong
module EmployeesHelper
end
