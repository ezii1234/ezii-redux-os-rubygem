# typed: strong
module StickRecordsHelper
end
