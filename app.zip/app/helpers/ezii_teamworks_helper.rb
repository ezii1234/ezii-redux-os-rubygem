# typed: strong
module EziiTeamworksHelper
end
