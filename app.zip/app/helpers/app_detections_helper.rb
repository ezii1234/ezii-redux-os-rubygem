# typed: strong
module AppDetectionsHelper
end
