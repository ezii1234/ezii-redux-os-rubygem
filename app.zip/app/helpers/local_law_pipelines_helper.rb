# typed: strong
module LocalLawPipelinesHelper
end
