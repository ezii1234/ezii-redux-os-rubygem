# typed: strong
module BanalComplexesHelper
end
