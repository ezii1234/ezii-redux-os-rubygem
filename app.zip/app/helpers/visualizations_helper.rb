# typed: strong
module VisualizationsHelper
end
