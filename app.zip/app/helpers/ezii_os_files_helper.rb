# typed: strong
module EziiOsFilesHelper
end
