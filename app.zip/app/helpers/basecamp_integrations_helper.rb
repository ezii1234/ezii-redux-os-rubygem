# typed: strong
module BasecampIntegrationsHelper
end
