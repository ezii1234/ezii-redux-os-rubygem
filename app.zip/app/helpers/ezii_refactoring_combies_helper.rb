# typed: strong
module EziiRefactoringCombiesHelper
end
