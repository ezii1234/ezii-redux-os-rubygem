# typed: strong
module ApplicationHelper
end
