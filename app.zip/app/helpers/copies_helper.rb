# typed: strong
module CopiesHelper
end
