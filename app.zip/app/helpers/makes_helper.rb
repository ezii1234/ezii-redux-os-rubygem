# typed: strong
module MakesHelper
end
