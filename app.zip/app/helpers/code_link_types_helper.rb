# typed: strong
module CodeLinkTypesHelper
end
