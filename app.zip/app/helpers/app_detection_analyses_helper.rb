# typed: strong
module AppDetectionAnalysesHelper
end
