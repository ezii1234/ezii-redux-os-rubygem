# typed: strong
module WitAiParseModelExamplesHelper
end
