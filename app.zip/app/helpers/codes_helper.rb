# typed: strong
module CodesHelper
end
