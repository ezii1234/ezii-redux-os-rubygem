# typed: strong
module SearchesHelper
end
