# typed: strong
module TypesHelper
end
