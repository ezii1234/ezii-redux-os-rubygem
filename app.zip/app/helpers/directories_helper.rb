# typed: strong
module DirectoriesHelper
end
