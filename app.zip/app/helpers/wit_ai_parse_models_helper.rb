# typed: strong
module WitAiParseModelsHelper
end
