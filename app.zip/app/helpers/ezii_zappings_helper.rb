# typed: strong
module EziiZappingsHelper
end
