# typed: strong
module EziiSeedsHelper
end
