# typed: strong
module CodeChangeRequestsHelper
end
