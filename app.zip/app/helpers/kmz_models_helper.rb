# typed: strong
module KmzModelsHelper
end
