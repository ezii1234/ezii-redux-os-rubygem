# typed: strong
module EziiIntegrationsHelper
end
