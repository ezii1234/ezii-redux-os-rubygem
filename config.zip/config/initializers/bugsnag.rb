# typed: strict
Bugsnag.configure do |config|
  config.api_key = "a516e59378b805b0ca10be5b3d80fb42"
end
