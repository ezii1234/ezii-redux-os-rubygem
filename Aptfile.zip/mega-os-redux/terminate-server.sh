
kill -9 $(cat ./tmp/pids/server.pid)
