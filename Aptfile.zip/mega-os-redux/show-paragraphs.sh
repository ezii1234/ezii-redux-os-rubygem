cat $0 | grep §
