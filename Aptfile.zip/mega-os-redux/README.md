# English

hey

#ezii


Set up on Dropbox (kind of optional)

Create a team business dropbox account

Create a team business dropbox api application

Gather the api keys

Configure API keys in rails credentials:

```ruby
    EDITOR=mate ruby -e credentials
```

< HEROKU VARIABLLE DOCUMENTATION GOES HERE >

```
RAILS_MASTER_KEY
RAILS_SERVE_STATIC_FILES
RAILS_ENV
RACK_ENV
DATABASE_URL
```


Heroku buildpacks, please in that order
```
https://github.com/heroku/heroku-buildpack-apt.git
heroku/ruby
https://github.com/carwow/heroku-buildpack-pdftotext.git
```


Deploy on heroku

Step 1: Fork this on Github
Step 2: Create a free (!) heroku account
Step 3: Create your free app on heroku
Step 4: Link your github account on heroku
Step 5: Go to heroku Deploy panel
Step 6: Deploy from Github
Step 7: Trial & Error until the website is online


< HEROKU DEPLOY BUTTON GOES HERE >




hey

#ezii


Set up on Dropbox (kind of optional)

Create a team business dropbox account

Create a team business dropbox api application

Gather the api keys

< HEROKU VARIABLLE DOCUMENTATION GOES HERE >

Deploy on heroku

Step 1: Fork this on Github
Step 2: Create a free (!) heroku account
Step 3: Create your free app on heroku
Step 4: Link your github account on heroku
Step 5: Go to heroku Deploy panel
Step 6: Deploy from Github
Step 7: Trial & Error until the website is online


< HEROKU DEPLOY BUTTON GOES HERE >


#  Deutsch

522/5000 Buchstaben


Hallo

#ezii


Auf Dropbox einrichten (Art optional)

Erstellen Sie ein Team Business Dropbox-Konto

Erstellen Sie eine Team Business Dropbox-API-Anwendung

Sammeln Sie die API-Schlüssel

<HEROKU VARIABLLE DOKUMENTATION GEHT HIER>

Bereitstellen auf Heroku

Schritt 1: Gabeln Sie dies auf Github
Schritt 2: Erstelle einen kostenlosen (!) Heroku-Account
Schritt 3: Erstellen Sie Ihre kostenlose App auf Heroku
Schritt 4: Verknüpfe deinen Github-Account mit Heroku
Schritt 5: Gehen Sie zum heroku Deploy Panel
Schritt 6: Bereitstellen von Github
Schritt 7: Trial & Error bis die Website online ist


<HEROKU DEPLOY BUTTON GEHT HIER>



# GIT DIFF 2 VRSIONS PACK 
git diff HEAD~2