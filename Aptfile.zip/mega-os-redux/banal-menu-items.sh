rake routes | grep banal
