
RR E D U X


What is important?


Pasted words I remembereed doing a REEDUX here




DELEETE STUFF


STUFF NOT NEEDED  TO START UP AN IDEA AT FIRST (like a computer program)


STUFF that the program fetches itself within time



Stuff that the app doesn’t need to have cached generally (10% congruent part of thee code)
