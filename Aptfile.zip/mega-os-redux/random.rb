# typed: strong
puts (1000^3) + (1001^3) - (1500^3)
