//
//  MegaOSBackgroundScriptControl.swift
//  keyDownViewController
//
//  Created by Manuel Arno Korfmann on 13.10.19.
//  Copyright © 2019 inDabusiness. All rights reserved.
//

import Foundation

class MegaOSBackgroundScriptControl {
    
}
